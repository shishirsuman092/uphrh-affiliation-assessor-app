export const APIS = {
   groundAnalysis: {
    viewForm: `/rest/getFormData`,
   }
};
  